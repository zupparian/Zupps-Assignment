import random
import string
import os

def generate_random_number():
    return random.randint(1, 9999)

def generate_random_letters():
    return ''.join(random.choices(string.ascii_uppercase, k=3))

def generate_plate_number(prefix):
    return f"{prefix}{generate_random_number():04d}{generate_random_letters()}"

def get_city_prefix(city):
    city = city.lower()
    if city == "bogor":
        return "F"
    elif city == "jakarta":
        return "B"
    else:
        raise ValueError("Nama kota tidak valid. Masukkan 'bogor' atau 'jakarta'.")

def save_plate_numbers(prefix, plate_numbers):
    if prefix == "B":
        city_file_prefix = "jakarta"
    elif prefix == "F":
        city_file_prefix = "bogor"
    else:
        raise ValueError("Prefix tidak valid.")

    folder = "results"
    if not os.path.exists(folder):
        os.makedirs(folder)

    counter = 0
    while True:
        file_name = f"{folder}/{city_file_prefix}{counter}.txt"
        if not os.path.exists(file_name):
            with open(file_name, 'w') as file:
                for plate_number in plate_numbers:
                    file.write(plate_number + "\n")
            break
        counter += 1

def main():
    city = input("Masukkan nama kota (bogor/jakarta): ")
    try:
        prefix = get_city_prefix(city)
    except ValueError as e:
        print(e)
        return

    plate_numbers = set()
    while len(plate_numbers) < 10:
        plate_number = generate_plate_number(prefix)
        if plate_number not in plate_numbers:
            plate_numbers.add(plate_number)

    # Convert set to list for ordered output
    plate_numbers = list(plate_numbers)

    # Display the message and generated plate numbers
    print("Berikut adalah 10 seri nomor polisi:")
    for plate_number in plate_numbers:
        print(plate_number)

    # Save the plate numbers to a file
    save_plate_numbers(prefix, plate_numbers)
    print("Nomor plat mobil telah disimpan.")

if __name__ == "__main__":
    main()